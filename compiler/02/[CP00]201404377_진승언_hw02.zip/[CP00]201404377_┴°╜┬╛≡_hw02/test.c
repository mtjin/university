int mX;
int mY = 1;
int test(int input)
{
	int tmp = 10;
	mX = 0;
	while(X < 10){
		mX = mX+ mY + 1;
	}
	if(mX > 5){
		mX = mX + tmp;
		return mX;  
	}else{
		return -1;
	}
}