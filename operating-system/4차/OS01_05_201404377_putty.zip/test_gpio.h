#define DEV_GPIO_MAJOR_NUMBER	221
#define DEV_GPIO_NAME		"GPIO_LED_TEST"
#define DEV_FILE_NAME		"/dev/gpio_led_driver"
