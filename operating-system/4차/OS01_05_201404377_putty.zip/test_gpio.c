#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <linux/kdev_t.h>
#include <stdlib.h>
#include "test_gpio.h"

void onLED(int fd){

int write_size, read_size;
char write_data, read_data;
while(1){
printf("LED On\n");


write_data = 1;
write(fd, &write_data, 1 );
sleep(1);

printf("LED Off now\n");
write_data = 0;
write_size = write(fd, &write_data, 1);
sleep(1);
}
} 
void main(int argc, char **argv){
int fd;
printf("Test GPIO\n");

mknod(DEV_FILE_NAME, (S_IRWXU|S_IRWXG|S_IFCHR), MKDEV(DEV_GPIO_MAJOR_NUMBER,0));





fd = open(DEV_FILE_NAME, O_RDWR|O_NONBLOCK);
if(fd<0){
printf("[Test_gpio] Error %d\n", fd);
exit(1);
}
else if(fd >= 0){
onLED(fd);
close(fd);
}
} 

